// replace()

import java.lang.*;
  
public class sb6
{ 
    public static void main(String[] args)
    {
 
        StringBuffer sbf = new StringBuffer("Welcome to Java World");
        System.out.println("string buffer = " + sbf);
 
        // Replacing substring from index 15 to index 18
        sbf.replace(11, 15, "Kava");
 
        System.out.println("After replacing string buffer = " + sbf);
    }
}
  
        
    