// append() method using char array.

import java.lang.*;
  
public class sb5
{
  
    public static void main(String[] args)
    {
  
        StringBuffer sbf = new StringBuffer("Hello ");
        System.out.println("Intput : " + sbf);
  
        // Char array
        char[] astr = new char[] { 'U','S','E','R' };
  
        /* Here it appends string representation of char array 
        argument to this string buffer */
        sbf.append(astr);
        System.out.println("Result after appending = " + sbf);
  
        // change the value of string 'sbf'
        sbf = new StringBuffer("Welcome to the java ");
  
        // Char array
        astr = new char[] { 'w','o', 'r', 'l', 'd' };
  
        sbf.append(astr);
        System.out.println("Result after appending = " + sbf);
    }
}