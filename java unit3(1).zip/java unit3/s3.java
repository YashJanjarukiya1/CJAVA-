//  startsWith() & endsWith() : 

public class s3
{
	public static void main(String[] args)
	{
		String s = "University";
		
		System.out.println(s.startsWith("U"));
		System.out.println(s.endsWith("i"));
	}
}