public class sb2 
{
   public static void main(String args[]) 
   {

      // declare an empty StringBuffer
      StringBuffer cap = new StringBuffer();

      //print the default capacity
      System.out.println("The default capacity: " + cap.capacity());
   }
}