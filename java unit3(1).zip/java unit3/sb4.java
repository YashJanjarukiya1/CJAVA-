// append() method

import java.lang.*;
  
public class sb4
{
  
    public static void main(String[] args)
    {
  
        StringBuffer sb1 = new StringBuffer("India is My Country ");
        System.out.println("Input: " + sb1);
  
        // Appending the boolean value
        sb1.append(true);
        System.out.println("Output: " + sb1);
  
        System.out.println();
  
        StringBuffer sb2 = new StringBuffer("All Indians are my Brothers and Sisters - ");
        System.out.println("Input: " + sb2);
  
        // Appending the boolean value
        sb2.append(false);
        System.out.println("Output: " + sb2);
    }
}