import java.lang.*;
 
public class sb7
{
 
    public static void main(String args[])
    {
        StringBuffer sbf = new StringBuffer("Hello");
        System.out.println("String buffer = " + sbf);
         
        // Here it reverses the string buffer
        sbf.reverse();
        System.out.println("String buffer after reversing = " + sbf);
    }
}