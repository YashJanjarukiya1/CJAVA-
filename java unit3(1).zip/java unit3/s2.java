// trim() : Eiminate or remove white space before & after the string.
class s2
{
	public static void main(String[] args)
	{
		String s = "  Gls  ";
		System.out.println("s = " + s);
		System.out.print(s.trim());
	}
}