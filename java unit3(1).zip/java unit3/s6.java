//  valueOf() : 

public class s6
{
	public static void main(String args[])
	{
		int a = 19;
		String s = String.valueOf(a);
		System.out.println(s + 19); // 1919
	}
}