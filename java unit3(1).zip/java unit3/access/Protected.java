//  Access Modifire : Protected

package mypack;  
import pack.*;  
  
class Protected extends C
{  
	public static void main(String args[])
	{  
		Protected obj = new Protected();  
		obj.msg();  
	}  
}  

/*
-> output :
darshan@darshan-Swift-SF314-43:~/Desktop/CORE JAVA/unit-3/access$ javac -d . A.java
darshan@darshan-Swift-SF314-43:~/Desktop/CORE JAVA/unit-3/access$ javac -d . Protected.java
darshan@darshan-Swift-SF314-43:~/Desktop/CORE JAVA/unit-3/access$ java mypack.Protected
Hello
darshan@darshan-Swift-SF314-43:~/Desktop/CORE JAVA/unit-3/access$ 
________________________________________________________________________________________________*/