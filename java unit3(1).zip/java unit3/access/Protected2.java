//  Method overriding usin access-modifire

class D
{  
	protected void msg()
	{
		System.out.println("Hello java");
	}  
}  
      
public class Protected2 extends D
{  
	void msg()
	{
		System.out.println("Hello java");
	}// Compile-Time Error 
	
	public static void main(String args[])
	{  
		Protected2 obj = new Protected2();  
		obj.msg();  
       }  
}  