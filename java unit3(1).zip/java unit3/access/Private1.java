class B
{  
	private B() // private constructor
	{
	}  
	void msg()
	{
		System.out.println("Hello java");
	}  
}

public class Private1
{  
	public static void main(String[] args)
	{  
		B obj = new B(); // Compile Time Error  
	}  
}  