package pack;  
public class C
{  
	protected void msg()
	{
		System.out.println("Hello");
	}  
}  