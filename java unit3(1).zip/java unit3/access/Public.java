package mypack;  
import pack.*;  
  
class Public
{  
	public static void main(String args[])
	{  
		A obj = new A();  
		obj.msg();  
	}  
}  

/*
-> output :
darshan@darshan-Swift-SF314-43:~/Desktop/CORE JAVA/unit-3/access$ javac -d . A.java
darshan@darshan-Swift-SF314-43:~/Desktop/CORE JAVA/unit-3/access$ javac -d . Public.java
darshan@darshan-Swift-SF314-43:~/Desktop/CORE JAVA/unit-3/access$ java mypack.Public
Hello
darshan@darshan-Swift-SF314-43:~/Desktop/CORE JAVA/unit-3/access$
___________________________________________________________________________________________________*/