// save by A.java  

package pack;  
public class A
{  
	public void msg()
	{
		System.out.println("Hello");
	}  
	void show()
	{
		System.out.println("Hello world");
	}  
	
}  