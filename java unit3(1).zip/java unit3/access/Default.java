//  Access Specifire : default
// save by Default.java  

package mypack;  
import pack.*;  

class Default
{  
	public static void main(String args[])
	{  
		A obj = new A(); // Compile Time Error  
		obj.show(); // Compile Time Error  
	}  
}  

/*
-> output :
darshan@darshan-Swift-SF314-43:~/Desktop/CORE JAVA/unit-3/access$ javac -d . A.java
darshan@darshan-Swift-SF314-43:~/Desktop/CORE JAVA/unit-3/access$ javac -d . Default.java
Default.java:11: error: msg() is not public in A; cannot be accessed from outside package
		obj.msg();//Compile Time Error  
		   ^
1 error
darshan@darshan-Swift-SF314-43:~/Desktop/CORE JAVA/unit-3/access$ 
________________________________________________________________________________________________*/