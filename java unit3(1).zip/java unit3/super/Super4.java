// Super is automatically invoke to the default constructor.

class Parent
{
	Parent() // default constructor
	{
		System.out.println("Parent constructor is called using 'super' \nParent is created");
	}
}

class Child extends Parent
{
	Child()
	{
		System.out.println("\nChild is created");
	}
}

class Super4
{
	public static void main(String args[])
	{
		Child c1 = new Child(); 
		
		/* at the time of object creation the super is automatically invoke the default constructor of super-class & sub-class. */
	}
}
