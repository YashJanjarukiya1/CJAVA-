// To invoke parent class data_members using 'Super' Keyword.

class Animal 
{
	String color = "White"; // instance variable
}

class Dog extends Animal
{
	String color = "Black";
	
	void printcolor()
	{
		System.out.println(color);
		System.out.println(super.color); // invoke parent class instance variable using 'super'.
	}
}

class Super1
{
	public static void main(String args[])
	{
		Dog d = new Dog();
		d.printcolor();
	}
}
