// Super keyword is access the parmeterized constructor of Parent class.

class Parent // Parent class
{
	int id;
	String name;
	Parent(int id,String name) // Parameterized constructor of parent
	{
		this.id = id;
		this.name = name;
	}
	
	void display()
	{
		System.out.println(id + "  " + name);
	}
}

class Child extends Parent // child class
{
	float sal;
	Child(int id,String name,float salary) // Parameterized constructor of child
	{
		super(id,name); // pass the value to the parameter constructor of parent class using super keyword.
		sal = salary;
	}

	void show()
	{
		System.out.println(id + "  " + name + "  " + sal);
	}
}

public class Super5
{
	public static void main(String args[])
	{
		Child c1 = new Child(101,"Hitesh",15650);  // pass the value to the parent & child-class's constructor
		c1.display();
		c1.show();
	}
}
