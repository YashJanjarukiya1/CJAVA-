// Super keyword can be invoke parent-class constructor.

class Animal // Parent or super class
{
	int id;
	String name;
	
	Animal() // default constructor of parent class
	{
		id = 10;
		name = "Riddhi";
		System.out.println("Parent is created");
	}
	
	void show()
	{
		System.out.println(id + "  " + name);
	}
}

class Dog extends Animal // child or sub class
{
	int id;
	String name;
	
	Dog() // default constructor of sub class
	{
		super(); // default constructor of parent class is called using 'super' keyword.
		super.show(); // fetch the method of parent class using 'super' keyword.

		id = 11;
		name = "Mohit";
		System.out.println("Child is created");
	}
	
	void display()
	{
		System.out.println(id + "  " + name);
	}
}

class Super3
{
	public static void main(String[] args)
	{
		Dog d = new Dog();
		d.display();
	}
}
