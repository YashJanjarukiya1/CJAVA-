// to invoke Parent class or super class method() using 'super' keyword.

class Animal // super class
{
	void eat()
	{
		System.out.println("Eating");
	}
}

class Dog extends Animal // sub class
{
	void eat()
	{
		System.out.println("Eating now..");
	}

	void bark()
	{
		System.out.println("Barking");
	}

	void work()
	{
		super.eat(); // invoke super class method using 'super' keyword
		eat(); 
		bark();
	}
}

class Super2
{	
	public static void main(String[] args)
	{
		Dog d1 = new Dog();
		d1.work();
	}
}
