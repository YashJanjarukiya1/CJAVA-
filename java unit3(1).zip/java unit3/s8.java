//  substr() :
//  syntax : public String substring(int beginIndex, int endIndex)

public class s8
{
	public static void main(String args[])
	{
		String Str = new String("Welcome to Java SYBCA AS44");
		System.out.println(Str.substring(11, 15)); // Java
	}
}