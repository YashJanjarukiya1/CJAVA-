/*     Abstract class can be done by Inheritence only.

Note : if you are extending the abstract-class, then the abstract 
	   class that have atleast one abstract method.

-> 	A method that is declared as abstract and does not have
   	implementation (or body part) is known as abstract method.
________________________________________________________________________________*/

abstract class AbstractClass
{
	abstract void Method(); 
}

class SubClass extends AbstractClass
{
	void Method()
	{
		System.out.println("Extract the abstract method through the sub_class method or inheritence");
	}
}

class A1
{
	public static void main(String[] args)
	{
		SubClass obj = new SubClass();
		obj.Method();
	}
}
