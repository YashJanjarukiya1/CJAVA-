/*  Abstract Keyword

->  An abstract class must be declared with an abstract keyword.
->  It can have abstract and non-abstract methods.
->  It cannot be instantiated.(we cannot create the object of the abstract class).
______________________________________________________________________________________*/

abstract class B // Abstract class
{
	abstract void method(); // abstract method (no body part)
}


class A extends B // subclass
{
	void method()
	{
		System.out.println("Abstarction can be done by Single Inheritence");
	}

	public static void main(String args[])
	{
		// we can't create abstract class's object
		B obj = new B(); 
		obj.method();      // Compile-time error
	}
}