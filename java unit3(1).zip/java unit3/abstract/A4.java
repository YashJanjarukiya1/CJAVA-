//  Abstract class have method body

abstract class Bike
{
	Bike() // default constructor
	{
		System.out.println("Bike is created");
	}

	abstract void run(); // abstract method

	void ChangeGear() // non-abstract method
	{
		System.out.println("Gear Changed");
	}
}

class Honda extends Bike
{
	void run()
	{
		System.out.println("Running Safely");
	}
}

class A4
{
	public static void main(String[] args)
	{
		Bike j1;

		j1 = new Honda();
		j1.run();
		j1.ChangeGear();
	}
}