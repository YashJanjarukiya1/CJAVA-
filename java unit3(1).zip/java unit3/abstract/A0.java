/* 
Note : 

-> in Abstract class, the abstract method doesn't have body part.
-> The body part of the abstract method can be executed by the subclass(child class).
___________________________________________________________________________________________*/

abstract class B // Abstract class
{
	abstract void method(); // abstract method (no body part)
}

class A0 extends B // subclass
{
	void method()
	{
		System.out.println("Abstarction can be done by Single Inheritence");
	}

	public static void main(String args[])
	{
		A0 a = new A0();
		a.method();
	}
}
