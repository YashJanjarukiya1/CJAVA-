/*  Extract the abstract-class using Hierarchical Inheritence. */

abstract class Shape
{
	abstract void Draw();
}

class Circle extends Shape
{
	void Draw()
	{
		System.out.println("Drawing Circle");
	}
}

class Triangle extends Shape
{
	void Draw()
	{
		System.out.println("Drawing Triangle");
	}
}

class Rectangle extends Shape
{
	void Draw()
	{
		System.out.println("Drawing Rectangle");
	}
}

class Square extends Shape
{
	void Draw()
	{
		System.out.println("Drawing Square");
	}
}

class A2
{
	public static void main(String[] args)
	{
		Shape obj;

		obj = new Circle();
		obj.Draw();

		obj = new Triangle();
		obj.Draw();

		obj = new Rectangle();
		obj.Draw();

		obj = new Square();
		obj.Draw();
	}
}