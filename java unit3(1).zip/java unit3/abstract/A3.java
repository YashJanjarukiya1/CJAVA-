/*  Extract the abstract class using Hierarchical Inheritence. */

abstract class Mom_Dad
{
	abstract int getRateOfInterest();
}

class Child1 extends Mom_Dad
{
	int getRateOfInterest()
	{
		return 6;
	}
}

class Child2 extends Mom_Dad
{
	int getRateOfInterest()
	{
		return 23;
	}
}

class Child3 extends Mom_Dad
{
	int getRateOfInterest()
	{
		return 29;
	}
}

class A3
{
	public static void main(String[] args)
	{
		Mom_Dad obj;

		obj = new Child1();
		System.out.println("child1 = " + obj.getRateOfInterest());

		obj = new Child2();
		System.out.println("child2 = " + obj.getRateOfInterest());

		obj = new Child3();
		System.out.println("child3 = " + obj.getRateOfInterest());

	}
}