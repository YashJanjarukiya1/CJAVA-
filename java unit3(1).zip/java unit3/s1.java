//  toUpperCase() & to LowerCase()

import java.lang.String;
class s1
{
	public static void main(String args[])
	{
		String s = "Ahmedabad";
		
		System.out.println("Convert the string into uppercase : " + s.toUpperCase());
		System.out.println("Convert the string into lowercase : " + s.toLowerCase());
	}
}