// capacity() and append() method.

public class sb3
{
   public static void main(String[] args) 
   {

      StringBuffer buff = new StringBuffer("");
      System.out.println("Default capacity = " + buff.capacity());  
    
      buff = new StringBuffer("Hello"); 
      System.out.println("current capacity = " + buff.capacity());

      buff = new StringBuffer("SYBCA div AS sem-3"); 
      System.out.println("After add new string capacity = " + buff.capacity()); // (16*2)+2 = 34

      buff = new StringBuffer("Appended String : " + buff.append("SYBCA div AS sem-3")); 
      System.out.println("After append() current capacity = " + buff.capacity()); // (34*2)+2 = 70
   }
}