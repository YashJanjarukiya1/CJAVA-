//  charAt() :

class s4
{
	public static void main(String args[])
	{
		String s = " Sachin";
		
		System.out.println(s.charAt(1));
		System.out.println(s.charAt(5));
	}
}