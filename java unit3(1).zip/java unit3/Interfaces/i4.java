/*  Interface Example */

interface printable
{  
	void print();  
	// this method is by default public & abstract
}  

class i4 implements printable
{  
	public void print()
	{	
		System.out.println("Hello java user");
	}  
      
	public static void main(String args[])
	{  
		i4 obj = new i4();  
		obj.print();  
	}  
}  
