/*   Abstract class Interface

Note : Interface cannot be instantiated just like abstract class.
____________________________________________________________________*/

interface A
{
	void a();
	void b();
	void c();
	void d();
}

abstract class B implements A
{
	public void c()
	{
		System.out.println("I am c()");
	}
	public void temp()
	{
		System.out.println("I am in Temp()");
	}
}

class C extends B
{
	public void a()
	{
		System.out.println("I am a()");
	}
	public void b()
	{
		System.out.println("I am b()");
	}
	public void d()
	{
		System.out.println("I am d()");
	}
}

class i3
{
	public static void main(String args[])
	{
		// here, A is interface, so it's object is not created.
		A obj = new C(); 
		obj.a();
		obj.b();
		obj.c();
		obj.d();
		
		C a1 = new C();
		a1.temp();
		a1.c();
	}
}