/*    Multiple Inheritence

-> If an interface extends multiple interfaces, i.e. known as multiple inheritance.
________________________________________________________________________________________*/

interface printable
{  
	public abstract void print();  
}  

interface runnable extends printable
{
	public abstract void run();
}
    
interface showable extends printable
{  
	public abstract void show();  
}  
    
class multiple2 implements showable,printable,runnable
{  
	public void print()
	{
		System.out.println("Print the Interface");
	} 	
	public void run()
	{
		System.out.println("Run the Interface");
	}  
	public void show()
	{
		System.out.println("Show the Interface");
	}  
      
	public static void main(String args[])
	{  
		multiple2 obj = new multiple2();  
		obj.print();  
		obj.run();
		obj.show();  
	}  
}  
