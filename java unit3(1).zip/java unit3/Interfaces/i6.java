/*
-> A class implements an interface, but one interface extends another interface. 
______________________________________________________________________________________*/

interface printable
{  
	public abstract void print();  
}  
    
interface showable extends printable
{  
	public abstract void show();  
}  
    
class i6 implements showable
{  
	public void print()
	{
		System.out.println("Print the Interface");
	} 	
	
	public void show()
	{
		System.out.println("Show the Interface");
	}  
      
	public static void main(String args[])
	{  
		i6 obj = new i6();  
		obj.print();  
		obj.show();  
	}  
}  
