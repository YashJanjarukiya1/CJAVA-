/*   Multiple Inheritence concept

Multiple-Interface : a class implements multiple-interfaces, i.e. known as Multiple inheritence.
-> Fetch one or more interfaces in single class.
__________________________________________________________________________________________________*/

interface printable
{  
	void print();  
}  

interface showable
{  
	void show();  
}  
    
class i6 implements printable,showable
{  
	public void print()
	{
		System.out.println("Hello world");
	}  
	public void show()
	{
		System.out.println("Welcome to the java world");
	}  
}

class multiple1
{      
	public static void main(String args[])
	{  
		i6 obj = new i6();  
		obj.print();  
		obj.show();  
	}  
}  
