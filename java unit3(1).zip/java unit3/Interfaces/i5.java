/*  -> In this example, the Drawable interface has only one method. 
	  Its implementation is provided by Rectangle and Circle classes. 
	  In a real scenario, an interface is defined by someone else, but 
	  its implementation is provided by different implementation 
	  providers.
	  Moreover, it is used by someone else. The implementation part is 
	  hidden by the user who uses the interface.
______________________________________________________________________________*/

//Interface declaration: by first user  
interface drawable
{  
	public abstract void draw();  
}  
   
//Implementation: by second user  
class rectangle implements drawable
{  
	public void draw()
	{
		System.out.println("drawing rectangle");
	}  
}  
//Implementation: by second user
class circle implements drawable
{  
	public void draw()
	{
		System.out.println("drawing circle");
	}  
}

//Using interface: by third user  
class i5
{  
	public static void main(String args[])
	{  
		drawable d;
		
		d = new circle();
		d.draw();  
		
		d = new rectangle();
		d.draw();
	}
}  
