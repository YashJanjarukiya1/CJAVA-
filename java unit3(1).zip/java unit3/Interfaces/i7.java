/*  Interface example using default method */

interface drawable
{  
	public abstract void draw();  

	default void msg()
	{
		System.out.println("default method");
	}  
}  

class rectangle implements drawable
{  
	public void draw()
	{
		System.out.println("drawing rectangle");
	}  
}

class i7
{  
	public static void main(String args[])
	{ 	 
		drawable d = new rectangle();  
		d.draw();  
		d.msg();  
	}
}  