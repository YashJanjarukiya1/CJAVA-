/*

->   in Interface class,
1.data_members can be directly converted by the compiler
   to 'public' access specifire,'static' keyword,and 'final' (to make it constant).
2.if we declare the method as non-abstract method, but the
    compiler can converted the method into the 'abstract method'.
_________________________________________________________________________________*/

interface printable
{
	int num = 12;
	// compile time : ( public static final int num = 12; )
	void fun(); 
	// compile time : ( public abstract void fun(); )
}

class i2 implements printable
{  
	public void fun()
	{
		System.out.println("Hello User");
	}  
  
	public static void main(String args[])
	{  
		i2 obj = new i2();
		System.out.println("num = " + obj.num);
		obj.fun();  
	}  
}  