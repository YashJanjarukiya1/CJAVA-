/*     INTERFACE :

->  Interface is used to achieve abstraction.
->  Interface has static,final (constants) variables.

Note : Interface have only abstract method, which doesn't have body part.
________________________________________________________________________________*/

interface Animal 
{
	public abstract void animalSound(); // interface method does not have a body)
	public abstract void sleep(); // interface method does not have a body)
}

// Pig "implements" the Animal interface
class Pig implements Animal 
{
	public void animalSound() 
	{
		//The body of animalSound() is provided here
		System.out.println("The pig says : wee wee");
	}
	public void sleep()
	{
		// The body of sleep() is provided here
		System.out.println("The pig sleep : Zzz.. Zzz..");
	}
}

class i1
{
	public static void main(String[] args) 
	{
		Pig myPig = new Pig(); // Create a Pig object
		myPig.animalSound();
		myPig.sleep();
	}
}
