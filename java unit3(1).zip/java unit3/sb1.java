//  String buffer class

public class sb1
{
    static String s2;
    sb1(String s)
    {
        s2 = s;
    }
    public static void main(String[] args)
    {
        String s1 = "Hello";
        String s3 = "Hello";
        
        StringBuffer sb = new StringBuffer("Hello");
        if(s2 == s1)
        {
            System.out.println(true);
        }
        else if(s3 == s1) 
        {
           System.out.println(1); // 1
        }
    }
}