public class sb8
{  
    public static void main(String[] args) 
    {  
        StringBuffer sb = new StringBuffer("Joomla is based on CMS");  
        System.out.println("string: " + sb);  

        
        // System.out.println("character at index -1 : " + sb.charAt(-1));  // generate exception error
        System.out.println("character at index 3 : " + sb.charAt(3));  
    }  
}  