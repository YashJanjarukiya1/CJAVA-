/*  topic : Access package from another package
    There are three ways to access the package from outside the package.

    3) Using fully qualified name
     -> step-1 : create package in file. 
____________________________________________________________________________*/

package E;

public class package6
{
    public void message()
    {
        System.out.println("Hello from package E's class package6");
    }
}
