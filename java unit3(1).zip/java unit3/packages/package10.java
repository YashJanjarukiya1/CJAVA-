/* Subpackages in java

-> step-2 : import subpackage from specific package using classname.
______________________________________________________________________*/

package pack2;

import abc.java.core.package8;

public class package10
{
	public static void main(String args[])
	{
		package8 a1 = new package8();
		a1.fun();
	}
}

/*
-->  output :
darshan@darshan-Swift-SF314-43:~/Desktop/CORE JAVA/unit-3/Packages$ javac -d . package10.java
darshan@darshan-Swift-SF314-43:~/Desktop/CORE JAVA/unit-3/Packages$ java pack2.package10
fun() method is calling
darshan@darshan-Swift-SF314-43:~/Desktop/CORE JAVA/unit-3/Packages$ 
*/
