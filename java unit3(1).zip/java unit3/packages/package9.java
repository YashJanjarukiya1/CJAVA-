/* Subpackages in java

-> step-2 : import subpackage from specific package using *.
________________________________________________________________*/

package pack1;

import abc.java.core.*;

public class package9
{
	public static void main(String args[])
	{
		package8 a1 = new package8();
		a1.fun();
	}
}

/*
-> output :
darshan@darshan-Swift-SF314-43:~/Desktop/CORE JAVA/unit-3/Packages$ javac -d . package8.java
darshan@darshan-Swift-SF314-43:~/Desktop/CORE JAVA/unit-3/Packages$ javac -d . package9.java
darshan@darshan-Swift-SF314-43:~/Desktop/CORE JAVA/unit-3/Packages$ java pack1.package9
fun() method is calling
darshan@darshan-Swift-SF314-43:~/Desktop/CORE JAVA/unit-3/Packages$ 
*/

