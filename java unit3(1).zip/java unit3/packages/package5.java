/*  topic : Access package from another package
    There are three ways to access the package from outside the package.
    2) Using packagename.classname;
     -> step-2 : importing a package from a particular class name. 
____________________________________________________________________________*/

package D;

import C.package4;

class package5
{
	public static void main(String[] args)
	{
		package4  o1  = new package4();
		o1.msg();
	}
}
