/* Subpackages in java

-> step-1 : create subpackage into particular package.
________________________________________________________________*/

package abc.java.core;

public class package8
{
	public void fun()
	{
		System.out.println("fun() method is calling");
	}
}

