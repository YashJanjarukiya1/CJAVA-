/*  topic : Access package from another package
    There are three ways to access the package from outside the package.
    2) Using packagename.classname;
     -> step-1 : calling a package with a specific file name. 
____________________________________________________________________________*/

package C;
public class package4
{
	public void msg()
	{
		System.out.println("Hello from package4 class");
	}
}