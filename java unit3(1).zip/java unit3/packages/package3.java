/*  topic : Access package from another package
    There are three ways to access the package from outside the package.
    1) Using packagename.*;
     -> step-2 : importing one package into another file. 
___________________________________________________________*/

package B;

import A.*;

/*
The import keyword is used to make the classes and interface of
another package accessible to the current package.
*/

public class package3
{
	public static void main(String[] args)
	{
		package2 obj = new package2();
		obj.msg();
	}
}

/*
-> output :
darshan@darshan-Swift-SF314-43:~/Desktop/CORE JAVA/unit-3/Packages$ javac -d . package3.java
darshan@darshan-Swift-SF314-43:~/Desktop/CORE JAVA/unit-3/Packages$ java B.package3
Hello..  from package A
darshan@darshan-Swift-SF314-43:~/Desktop/CORE JAVA/unit-3/Packages$ 
*/
