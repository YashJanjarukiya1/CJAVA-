/*  -> Package example-1
     -> create the package within the same directory,
          you can use '.' (dot).
___________________________________________________________*/

package firstPackage; // package created

public class package1
{
	public static void main(String[] args)
	{
		System.out.println("Welcome to Package");
	}
}

/*
--> output :

darshan@darshan-Swift-SF314-43:~/Desktop/CORE JAVA/unit-3/Packages$ javac -d . package1.java
darshan@darshan-Swift-SF314-43:~/Desktop/CORE JAVA/unit-3/Packages$ java firstPackage.package1
Welcome to Package
darshan@darshan-Swift-SF314-43:~/Desktop/CORE JAVA/unit-3/Packages$ 

*/