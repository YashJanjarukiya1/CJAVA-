/*  topic : Access package from another package
    There are three ways to access the package from outside the package.

    3) Using fully qualified name
     -> step-2 : importing a package using fully qualified name. 
____________________________________________________________________________*/

package F;

class package7
{
    public static void main(String args[])
    {
        E.package6 object = new E.package6();
        object.message();
    }
}