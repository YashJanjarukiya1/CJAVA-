/*  topic : Access package from another package
    There are three ways to access the package from outside the package.
    1) Using packagename.*;
     -> step-1 : create package in file. 
______________________________________________*/

package A;
public class package2
{
	public void msg()
	{
		System.out.println("Hello.. from package A");
	}
}
