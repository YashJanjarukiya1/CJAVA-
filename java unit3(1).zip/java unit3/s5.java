//  length() : 

public class s5
{
	public static void main(String args[])
	{
		String str = "SitaRam ";
		
		System.out.println(str.length()); // 8
	}
}