class sb9
{
    public static void main(String args[])
    {
          StringBuffer str = new StringBuffer("I'm complete my BCA");
  
        // print string
        System.out.println("String = " + str.toString());
  
        // setchar at index 16 to 'M'
        str.setCharAt(16, 'M');
  
        // print string
        System.out.println("After setCharAt() String = "+ str.toString());
    }
}