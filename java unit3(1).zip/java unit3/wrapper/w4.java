//  Convert Wrapper class object into primitive data type.

public class w4
{
	public static void main(String[] args)
	{
		// convert wrapper class object
		
		Integer i = Integer.valueOf(23);
		Short S= Short.valueOf((short) 10);
		Long l = Long.valueOf(1234567895);
		Byte B = Byte.valueOf((byte) 65);
		Float F = Float.valueOf(19.13f);
		Double d = Double.valueOf(365.55);
		Character ch = Character.valueOf('D'); 
		Boolean b = Boolean.valueOf(true);

		// into primitive types
		
		int Int = i.intValue();
		short Short = S.shortValue();
		long Long = l.longValue();
		byte Byte = B.byteValue();
		float Float = F.floatValue();
		double Double = d.doubleValue();
		char Char = ch.charValue();
		boolean Bool = b.booleanValue();
		
		System.out.println("converts Wrapper class objects into primitive types\n");

		System.out.println("int : " + Int);
		System.out.println("short : " + Short);
		System.out.println("long : " + Long);
		System.out.println("byte : " + Byte);
		System.out.println("float : " + Float);
		System.out.println("double : " + Double);
		System.out.println("char : " + Char);
		System.out.println("boolean : " + Bool);
	}
}