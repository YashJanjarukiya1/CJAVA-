// converting primitive data type into wrapper object class

public class w5
{
	public static void main(String args[])
	{
		//  Integer x = new Integer(50); // <-  this command generate warning at compile-time..!!
		Integer x = Integer.valueOf(50);
		System.out.println("x = " + x);
		
		//  Float y = new Float(90f); // <-  this command generate warning at compile-time..!!
		Float y = Float.valueOf(90f);
		System.out.println("y = " + y);
		
		System.out.println("x == y : " + x.equals(y)); // false
		System.out.println("x == 50 : " + x.equals(50)); // true
	}
}