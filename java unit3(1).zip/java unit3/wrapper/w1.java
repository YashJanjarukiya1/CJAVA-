//  Java program to convert primitive into objects  

public class w1
{  
	public static void main(String[] args)
	{  
		// Converting int into Integer  
		int a = 20;  
		
		Integer i = Integer.valueOf(a); // converting int into Integer explicitly  
		System.out.println("i : " + i);
	}
}  

/*
output :
darshan@darshan-Swift-SF314-43:~/Desktop/CORE JAVA/unit-3/wrapper$ javac w1.java
darshan@darshan-Swift-SF314-43:~/Desktop/CORE JAVA/unit-3/wrapper$ java w1
i : 20
darshan@darshan-Swift-SF314-43:~/Desktop/CORE JAVA/unit-3/wrapper$ 
________________________________________________________________________________________*/