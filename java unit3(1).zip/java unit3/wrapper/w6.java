//  Converting Primitives to String object
public class w6 
{
	public static void main(String args[])
	{
		float val = 10.8f;
		System.out.println(val+val); // 21.6
		
		String str = Float.toString(val);
		System.out.println("String : " + (str+val)); // 10.810.8
	}
}