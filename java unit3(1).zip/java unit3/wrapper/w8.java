// primitive to wrapper class or Auto-boxing (shortcut)

public class w8
{
	public static void main(String args[])
	{
		byte b = 10; // primitive
		Byte B = b;
		int i = 6;
		Integer I = i;
		short s = 5;
		Short S = s;
		long l = 1234567890;
		Long L = l;
		float f = 14.12f;
		Float F = f;
		double d = 234.87;
		Double D = d;
		char c = 'A';
		Character Ch = c;
		boolean bool = true;
		Boolean Bool = bool;
		
		// autoboxing of primitive data-types are below
		System.out.println("-------Auto-Boxing-------");
		System.out.println("Byte = " + B);
		System.out.println("Int = " + I);
		System.out.println("Short = " + S);
		System.out.println("Long = " + L);
		System.out.println("Float = " + F);
		System.out.println("Double = " + D);
		System.out.println("Character = " + Ch);
		System.out.println("Boolean = " + Bool);
	}
}