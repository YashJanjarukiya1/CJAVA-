//  Converting primitive data type to object class

public class w3
{
	public static void main(String[] args)
	{  
		System.out.println("Converting primitive data type to object class\n");
		
		int a = 23;  
		
		Integer i = Integer.valueOf(a); // converting int into Integer explicitly  
		System.out.println("int : " + i);
		
		short s = 3;  
		
		Short sh = Short.valueOf(s); // converting short into Short explicitly  
		System.out.println("short : " + sh);
		
		long l = 234708423;  
		
		Long L = Long.valueOf(l); // converting long into Long explicitly  
		System.out.println("long : " + L);
		
		byte BYTE = 10;  
		
		Byte B = Byte.valueOf(BYTE); // converting byte into Byte explicitly  
		System.out.println("byte : " + B);
		
		float f = 13.5f;  
		
		Float F = Float.valueOf(f); // converting float into Float explicitly  
		System.out.println("float : " + F);
		
		double d = 234.1240;  
		
		Double D = Double.valueOf(d); // converting double into Double explicitly  
		System.out.println("double : " + D);
		
		char c = 'M';  
		
		Character ch = Character.valueOf(c); // converting char into Character explicitly  
		System.out.println("char : " + ch);
		
		boolean b = false; 
		
		Boolean bool = Boolean.valueOf(b); // converting bool into Boolean explicitly  
		System.out.println("boolean : " + bool);
	}
}