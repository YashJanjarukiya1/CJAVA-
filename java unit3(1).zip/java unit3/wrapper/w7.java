//  converting String Object to Primitives

public class w7
{
	public static void main(String[] args)
	{
		String str = "99";
		short val = Short.parseShort(str);
		System.out.println(val);
	}
}