//  converting wrapper objects to primitives

public class w2
{
	public static void main(String[] args)
	{
		//  Integer i = new Integer(10); // <-  generate Warning..!!
		Integer i = Integer.valueOf(10);
		int a = i.intValue();
		
		System.out.println("a = " + a);
	}
}

/*
output :
darshan@darshan-Swift-SF314-43:~/Desktop/CORE JAVA/unit-3/wrapper$ javac w2.java
darshan@darshan-Swift-SF314-43:~/Desktop/CORE JAVA/unit-3/wrapper$ java w2
a = 10
darshan@darshan-Swift-SF314-43:~/Desktop/CORE JAVA/unit-3/wrapper$ 
__________________________________________________________________________________________________*/
