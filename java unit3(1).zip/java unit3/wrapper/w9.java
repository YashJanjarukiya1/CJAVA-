// wrapper class to primitive data-type or Auto-unboxing(shortcut)

public class w9
{
	public static void main(String args[])
	{
		Byte B = 2;
		byte b = B; 
		Integer I = 15;
		int i = I;
		Short S = 4;
		short s = S;
		Long L = 1234567890l;
		long l = L;
		Float F = 39.11f;
		float f = F;
		Double D = 520.121;
		double d = D;
		Character Ch = 'J';
		char c = Ch;
		Boolean Bool = false;
		boolean bool = Bool;
		
		// unboxing of wrapper class are below :
		System.out.println("-------Auto-UnBoxing-------");
		System.out.println("Byte = " + b);
		System.out.println("Int = " + i);
		System.out.println("Short = " + s);
		System.out.println("Long = " + l);
		System.out.println("Float = " + f);
		System.out.println("Double = " + d);
		System.out.println("Character = " + c);
		System.out.println("Boolean = " + bool);
	}
}