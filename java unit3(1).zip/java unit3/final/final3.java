//  If you make any class as final, you cannot extend it.

// This program generate compile-time error..

final class Parent // final class
{
	int r = 50;
}

class Child extends Parent
{
	void run()
	{
		System.out.println("Running safely 100kph");
	}
}

public class final3
{
	public static void main(String[] args)
	{
		Child f1 = new Child();
		f1.run();
		System.out.println("r = " + f1.r);
	}
}