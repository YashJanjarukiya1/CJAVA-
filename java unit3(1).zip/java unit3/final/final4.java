//  final variable can be initialized in the constructor also.

class A
{
	final int num; // decalare final variable
	
	A(int no) // parametrized constructor
	{
		num = no;
	}
	
	void show()
	{
		System.out.println("A is called\nnum = " + num);
	}
}

class B extends A
{
	B(int no)
	{
		super(no);
	}
	
	void display()
	{
		System.out.println("\nB is called");
	}
}

public class final4
{
	public static void main(String[] args)
	{
		B b1 = new B(50);
		b1.show();
		b1.display();
	}
}