/*   Java Program to demonstrate Different Ways of Initializing a final Variable.
__________________________________________________________________________________*/ 

class final1
{
	final int t = 5; // final variable direct initialize
	
	final int Capacity;  // a blank final variable
	// instance initializer block for initializing 'Capacity'
	{
		Capacity = 25;
	}
	
	static final double PI = 3.141592653589793; // final static variable PI direct initialize
	
	static final double C; // a blank final static  variable
	// static initializer block for initializing 'C'
	static
	{
		C = 2.3;
	}
	
	final int m; // another blank final variable
	final1()// constructor for initializing 'm'
	{
		m = 22;
	}
	
	void display()
	{
		System.out.println("t = " + t);
		System.out.println("Capacity = " + Capacity);
		System.out.println("PI = " + PI);
		System.out.println("C = " + C);
		System.out.println("m = " + m);
	}
         
	public static void main(String args[])
	{
		final1   a   =   new  final1();
		a.display();
	}
}