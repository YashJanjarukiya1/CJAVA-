// Final variables : declaration & initialization.

class final1_1
{
	final int SpeedLimit = 92; // final variable declare & initialization
	
	void run()
	{
		System.out.println(SpeedLimit);
	}
	
	public static void main(String args[])
	{
		final1_1 f1 = new final1_1();
		f1.run();
	}
}
