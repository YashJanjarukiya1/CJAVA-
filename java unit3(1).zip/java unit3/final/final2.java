//  This program generate compile-time error

class A 
{
	final void m1() 
	{
		System.out.println("This is a final method.");
	}
}

class B extends A 
{
	void m1()
	{		 
		// Compile-error! We can not override the final method
		System.out.println("Illegal!");
	}
}

public class final2
{
	public static void main(String args[])
	{
		B obj = new B();
		obj.m1();
	}
}