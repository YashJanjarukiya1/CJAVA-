// Final class 

final class Parent // final class
{
	int r;
}

class final3_1
{
	void run()
	{
		System.out.println("Running safely 100kph");
	}

	public static void main(String[] args)
	{
		final3_1 f1 = new final3_1();
		f1.run();

		Parent obj = new Parent();
		obj.r = 102;
		System.out.println("r = " + obj.r);
	}
}