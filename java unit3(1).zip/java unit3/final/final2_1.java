// we can directly access the Final method using 'super' and the name of final method.

class Parent
{
	final void run() // final method
	{
		System.out.println("Final method of parent-class is called \nRunning..");
	}
}

class final2_1 extends Parent
{
	void run1()
	{
		super.run(); // Parent-class is called using 'super' keyword.
		
		run(); // Parent-class is called using final-method() name.
		
		System.out.println("\nChild class \nRunning safely..");
	}

	public static void main(String args[])
	{
		final2_1 o1 = new final2_1();
		o1.run1();
	}
}
