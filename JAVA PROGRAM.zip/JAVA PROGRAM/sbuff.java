class sbuff
{
	public static void main(String args[])
	{
		StringBuffer sb=new StringBuffer();
		System.out.println("capacity "+sb.capacity());
		System.out.println("append "+sb.append("123456789"));
		System.out.println("Length "+sb.length());
		System.out.println("replace "+sb.replace(2,4,"aaaa"));
		System.out.println("reverse "+sb.reverse());
		System.out.println("capacity "+sb.capacity());
		System.out.println("append again "+sb.append("87654321"));
		System.out.println("length "+sb.length());
		System.out.println("capacity "+sb.capacity());
		System.out.println("charat "+sb.charAt(3));
		sb.setCharAt(3,'a');
		System.out.println("setcharat "+sb);
	}
}
