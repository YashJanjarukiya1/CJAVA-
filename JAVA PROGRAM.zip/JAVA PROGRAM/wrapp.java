class wrapp
{
	public static void main(String args[])
	{
		Byte b1=new Byte((byte)10);
		Byte b2=new Byte("10");
		System.out.println("b1"+b1);
		System.out.println("b2"+b2);
		
		Short s1=new Short((short)20);
		Short s2=new Short("20");
		System.out.println("s1"+s1);
		Integer i1=new Integer(40);
	}
}