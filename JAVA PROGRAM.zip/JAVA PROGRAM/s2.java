import java.lang.String;
class s2
{
	public static void main(String args[])
	{
		String s="Sachin";
		System.out.println("charat"+s.charAt(0));
		System.out.println("upper"+s.toUpperCase());
		System.out.println("lower"+s.toLowerCase());
	}
}