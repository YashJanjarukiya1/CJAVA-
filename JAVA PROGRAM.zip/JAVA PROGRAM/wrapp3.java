class  wrapp2
{
	public static void main(String args[])
	{
		int x=Integer.parseInt("a");
		double d=Double.parseDouble("5");
		int i=Integer.parseInt("16");
		System.out.println(x);
		System.out.println(d);
		System.out.println(i);
		int c=new Integer(15);
		String a=Interger.toString(c);
		System.out.println(a);	
	}
}