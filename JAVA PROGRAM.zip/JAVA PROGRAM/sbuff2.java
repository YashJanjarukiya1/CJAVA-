class sbuff2
{
	public static void main(String args[])
	{
		StringBuffer sb=new StringBuffer();
		System.out.println("capacity "+sb.capacity());
		System.out.println("append "+sb.append("Hello"));
		System.out.println("capacity "+sb.capacity());
		System.out.println("append "+sb.append("abcd"));
		System.out.println("Length "+sb.length());
		System.out.println("capacity "+sb.capacity());
		System.out.println(sb);
		System.out.println("append "+sb.append("world"));
		System.out.println("Length "+sb.length());
		System.out.println("capacity "+sb.capacity());
		System.out.println(sb);
	}
}