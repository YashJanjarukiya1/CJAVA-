class buffer2
{
	public static void main(String args[])
	{
		byte b=10;
		Byte b1=b;
		System.out.println(b1);
	}
}
