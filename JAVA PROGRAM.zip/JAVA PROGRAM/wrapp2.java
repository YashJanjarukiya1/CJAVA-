class  wrapp2
{
	public static void main(String args[])
	{
		Byte B=new Byte((byte)10);
		byte b=B.byteValue();
		System.out.println(b);
	}
}