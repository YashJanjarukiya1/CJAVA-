/*  (Demo of DataInputStream & DataOutputStream class)
    Q. write a java program to write data into file using DataOutputStream
    and read data from a file using DataInputStream & print data on terminal.
_________________________________________________________________________________*/

import java.io.*;

public class I
{
	public static void main(String[] args)
	{
		File f1 = new File("Hello1.dat");

		try
		{
			DataOutputStream d1 = new DataOutputStream(new FileOutputStream(f1));

			d1.writeInt(3200);
			d1.writeFloat((float)23.15);
			d1.writeLong((long)99203216);

			System.out.println("File is created");
			d1.close();

			System.out.println("-------------------------");

				DataInputStream d2 = new DataInputStream(new FileInputStream(f1));

				System.out.println(d2.readInt()); // 3200
				System.out.println(d2.readFloat()); // 23.15
				System.out.println(d2.readLong()); // 99203216

			System.out.println("-------------------------");

			d2.close();
		}
		catch(FileNotFoundException f)
		{
			System.out.println("File is not found");
		}
		catch(IOException e)
		{
			System.out.println(e);
		}
	}
}