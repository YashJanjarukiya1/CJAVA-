/*	Demo of RandomAccessInputFile & RandomAccessOutputFile.

Q.1 java program to write data into file using RandomAccessFile.
__________________________________________________________________*/

import java.io.*;

public class P
{
	public static void main(String args[])
	{
		File f = new File("Random.txt");

		int a = 436;
		long b = 5687394;
		String c = "This is a demo String";
		float d = 23.7f;

		try  
		{
			RandomAccessFile raf = new RandomAccessFile(f,"rw");

			raf.writeInt(a);
			raf.writeLong(b);
			raf.writeUTF(c);
			raf.writeFloat(d);
			raf.close();

			System.out.println("Data is written in file..");
		}
		catch(IOException e)
		{
			System.out.println(e);
		}
	}
}
