/* 	Q.Write a java program to read object data of 
	Biodata class from file and display it on screen
	or Terminal. 
__________________________________________________________*/
import java.io.*;

class Biodata implements Serializable
{
	String name;
	int age;
	String adr1;
	String adr2;
	
	Biodata(String nm, int ag, String ad1, String ad2)
	{
		name = nm;
		age = ag;
		adr1 = ad1;
		adr2 = ad2;
	}

	void PrintBioData()
	{
		System.out.println("Name: " + name);
		System.out.println("Age: " + age);
		System.out.println("Address 1: " + adr1);
		System.out.println("Address 2: " + adr2);
	}

}// end of class Biodata

class L2
{

	public static void main(String args[])
	{
		Biodata obj;
		try
		{
			FileInputStream fi = new FileInputStream("Biodata.dat");
			ObjectInputStream oi1 = new ObjectInputStream(fi);

			System.out.println("-------------------------------");
			for(int i=0; i<3;i++)
			{
				obj = (Biodata) oi1.readObject();
				obj.PrintBioData();
				
				System.out.println("-------------------------------");
			}
			oi1.close();

		}
		catch(FileNotFoundException e)
		{
			System.out.println("File not found");
		}
		catch(ClassNotFoundException e)
		{
			System.out.println("Class not found error");
		}
		catch(IOException e)
		{
			System.out.println("IO Error");
		}
	}
}

/*
darshan@darshan-Swift-SF314-43:~/Desktop/Advance Java/unit1$ javac L2.java
darshan@darshan-Swift-SF314-43:~/Desktop/Advance Java/unit1$ java L2
-------------------------------
Name: Sheetal
Age: 24
Address 1: Satellite
Address 2: Ahmdedabad
-------------------------------
Name: Darshan
Age: 18
Address 1: Ranip
Address 2: Ahmdedabad
-------------------------------
Name: Niketan
Age: 20
Address 1: Maninagar
Address 2: Ahmdedabad
-------------------------------
darshan@darshan-Swift-SF314-43:~/Desktop/Advance Java/unit1$ 
*/
