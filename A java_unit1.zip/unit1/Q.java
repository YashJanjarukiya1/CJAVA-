/* 

Que : Write a java program to access/read random data using
	  RandomAccessFile method.
______________________________________________________________*/

import java.io.*;

class Q
{
	public static void main(String args[])
	{		
		int a;
		long b;
		String c;
		float d;
		long a1,b1,c1,d1;
		
		try
		{
			RandomAccessFile raf = new RandomAccessFile("Random.txt","rw");

			System.out.println("File size is : " + raf.length());

			System.out.println("--------------------------------");
				
				a1 = raf.getFilePointer();
				a = raf.readInt();
				System.out.println("int a = " + a);
	
				b1 = raf.getFilePointer();
				b = raf.readLong();
				System.out.println("Long b = " + b);

				c1 = raf.getFilePointer();
				c = raf.readUTF();
				System.out.println("String c = " + c);

				d1 = raf.getFilePointer();
				d = raf.readFloat();
				System.out.println("Float d = " + d);

			System.out.println("--------------------------------");

				raf.seek(d1);
				d = raf.readFloat();
				System.out.println("Float d = " + d);
			
			raf.close();
			
		}
		catch(IOException e)
		{
			System.out.println("I/O problem");
		}
	}
}

