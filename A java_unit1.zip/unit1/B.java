// File Reading using FileInputStream.

/*  This program Read one by one 'byte' from file and 
    convert it into 'character' and display on Monitor.
_________________________________________________________*/

import java.io.*;

class B
{
	public static void main(String[] args)
	{
		try
		{
			int a;

			FileInputStream f1 = new FileInputStream("A.txt");

			while((a = f1.read()) != -1)
			{
				System.out.print((char)a);
			}
			f1.close();
		}
		catch(IOException e)
		{
			System.out.println("error");
		}
	}
}

/*
______________________________

A.txt 

1
2
3
4
5
6
7
8
9
10
______________________________

-> output :
darshan@darshan-Swift-SF314-43:~/Desktop/Advance Java$ javac B.java
darshan@darshan-Swift-SF314-43:~/Desktop/Advance Java$ java B
1
2
3
4
5
6
7
8
9
10
darshan@darshan-Swift-SF314-43:~/Desktop/Advance Java$
*/