/* 
-> 	Write a java program to perform following operation
	on given file.
	1) get the absolute path of the file.
	2) Rename file.
	3) set file into ReadOnly mode.
___________________________________________________________*/

import java.io.File;
public class F
{
	public static void main(String[] args)
	{
		File OldObj = new File("F1.dat");

		if(OldObj.exists())
		{
			System.out.println("Absolute path : " + OldObj.getAbsolutePath());

			boolean flag = OldObj.setReadOnly();

			if(flag == true)
			{
				System.out.println("File is converted into Read-Only mode..");
			}
			else
			{
				System.out.println("Unsuccessful operation..");
			}

			File NewObj = new File("F1.txt");

			if(OldObj.renameTo(NewObj))
			{
				System.out.println("File is renamed Successfully..");
			}
			else
			{
				System.out.println("Error..!!");
			}
		}
		else
		{
			System.out.println("File is also converted into read-only mode..");
		}
	}
}

/*
darshan@darshan-Swift-SF314-43:~/Desktop/Advance Java/unit1$ javac F.java
darshan@darshan-Swift-SF314-43:~/Desktop/Advance Java/unit1$ java F
Absolute path : /home/darshan/Desktop/Advance Java/unit1/myFile.dat
File is converted into Read-Only mode..
File is renamed Successfully..
darshan@darshan-Swift-SF314-43:~/Desktop/Advance Java/unit1$ 
*/
