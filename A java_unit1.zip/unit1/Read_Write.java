/*  use of 'FileInputStream & FileOutputStream' class.
	This program Read data from one file & write into
	second file. */

import java.io.*;

class Read_Write
{
	public static void main(String args[])
	{
		try
		{
			int c;

			FileInputStream f1 = new FileInputStream("B.dat");
			FileOutputStream f2 = new FileOutputStream("Read_Write.dat");

			while((c = f1.read()) != -1)
			{
				f2.write(c);
				System.out.print((char)c);
			}
						
			f1.close();
			f2.close();

			System.out.println("\nFile is copied.. from B.dat to Read_Write.dat");

		}
		catch(IOException e)
		{	
			System.out.println("error");
		}
	}
}

/*
darshan@darshan-Swift-SF314-43:~/Desktop/Advance Java/unit1$ javac Read_Write.java
darshan@darshan-Swift-SF314-43:~/Desktop/Advance Java/unit1$ java Read_Write
1
2
3
4
5
6
7
8
9
10
ABCDEFGHIJKLMNOPQRSTUVWXYZ
File is copied.. from B.dat to Read_Write.dat
darshan@darshan-Swift-SF314-43:~/Desktop/Advance Java/unit1$ 

__________________________________________________________*/
