/*  ->  importing File class.
( here, program and file in the same folder )

Note : 1) File class is used to know the details of the particular file,
		  which is already exist inside the folder.
  	   2) Using this class we cannot read or write from/to file. 
  	   3) We can't create any file using File class.
___________________________________________________________________________*/

import java.io.File;

class A
{
	public static void main(String args[])
	{
		File f1 = new File("A.txt");
		System.out.println("File is created");

		if(f1.exists()) //  File class's object is used to know details of file
		{
			System.out.println("File is exists");
		}
		else 
		{
			System.out.println("Not Available");
		}
	}
}
