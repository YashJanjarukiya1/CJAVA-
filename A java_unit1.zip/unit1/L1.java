/* 	Q.Write a java program to create object of Biodata class,
	& write data into file & show on Terminal also. 
________________________________________________________________*/

import java.io.*;

class Biodata implements Serializable
{
	String name;
	int age;
	String adr1;
	String adr2;
	
	Biodata(String nm, int ag, String ad1, String ad2)
	{
		name = nm;
		age = ag;
		adr1 = ad1;
		adr2 = ad2;
	}

	void PrintBioData()
	{
		System.out.println("Name: " + name);
		System.out.println("Age: " + age);
		System.out.println("Address 1: " + adr1);
		System.out.println("Address 2: " + adr2);
	}

}// end of class Biodata

class L1
{

	public static void main(String args[])
	{
		try
		{
			FileOutputStream fo1 = new FileOutputStream("Biodata.dat");

			ObjectOutputStream objos = new ObjectOutputStream(fo1);

			Biodata b1 = new Biodata("Sheetal", 24,"Satellite", "Ahmdedabad");
			Biodata b2 = new Biodata("Darshan", 18,"Ranip", "Ahmdedabad");
			Biodata b3 = new Biodata("Niketan", 20,"Maninagar", "Ahmdedabad");

			System.out.println("------------------------");
				b1.PrintBioData();
			System.out.println("------------------------");
				b2.PrintBioData();
			System.out.println("------------------------");
				b3.PrintBioData();
			System.out.println("------------------------");

			objos.writeObject(b1);
			objos.writeObject(b2);
			objos.writeObject(b3);

			objos.flush(); // flush() method is used to CleanUp the object
			objos.close();

		}
		catch(FileNotFoundException e)
		{
			System.out.println("File not found");
		}
		catch(IOException e)
		{
			System.out.println("IO Error");
		}
	}
}//end of class Objectoutput

/*
darshan@darshan-Swift-SF314-43:~/Desktop/Advance Java/unit1$ javac L1.java
darshan@darshan-Swift-SF314-43:~/Desktop/Advance Java/unit1$ java L1
------------------------
Name: Sheetal
Age: 24
Address 1: Satellite
Address 2: Ahmdedabad
------------------------
Name: Darshan
Age: 18
Address 1: Ranip
Address 2: Ahmdedabad
------------------------
Name: Niketan
Age: 20
Address 1: Maninagar
Address 2: Ahmdedabad
------------------------
darshan@darshan-Swift-SF314-43:~/Desktop/Advance Java/unit1
*/
