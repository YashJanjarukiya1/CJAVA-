/* Demo of ObjectInputStream & ObjectOutputStream class. */

import java.io.*;

class J
{
	public static void main(String args[])
	{
		int d = 5;
		String a = "Hello";

		try
		{
			FileOutputStream f1 = new FileOutputStream("G.txt");

			ObjectOutputStream o1 = new ObjectOutputStream(f1);

			o1.writeInt(d);
			o1.writeObject(a);

			FileInputStream f2 = new FileInputStream("G.txt");

			ObjectInputStream o2 = new ObjectInputStream(f2);

			System.out.println("---------------------");

				System.out.println("Int data : " + o2.readInt());
				System.out.println("String data : " + o2.readObject());

			System.out.println("---------------------");

			f2.close();
			o2.close();
		}
		catch(Exception e)
		{
			e.getStackTrace();
		}
	}
}
/*
darshan@darshan-Swift-SF314-43:~/Desktop/Advance Java/unit1$ javac J.java
darshan@darshan-Swift-SF314-43:~/Desktop/Advance Java/unit1$ java J
---------------------
Int data : 5
String data : Hello
---------------------
darshan@darshan-Swift-SF314-43:~/Desktop/Advance Java/unit1$ 
*/