/* 
	Create a java program to read data from two different
	files and mearge into third binary file.
*/
import java.io.*;

class D
{
	public static void main(String[] args)
	{
		try
		{
			int c;
			FileInputStream f1 = new FileInputStream("A.txt");
			FileInputStream f2 = new FileInputStream("A.dat");
			FileOutputStream f3 = new FileOutputStream("B.dat");

			while((c = f1.read()) != -1)
			{
				f3.write(c);
				//System.out.print((char)c);
			}
			f1.close();

			while((c = f2.read()) != -1)
			{
				f3.write(c);
				//System.out.print((char)c);
			}
						
			f2.close();
			f3.close();
			System.out.println("File is created");
		}
		catch(IOException e)
		{	
			System.out.println(e);
		}
	}
}
