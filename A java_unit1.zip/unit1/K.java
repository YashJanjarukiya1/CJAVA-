//  ObjectInputStream & OutputStream with 'serializable' interface.

import java.io.*;

class Dog implements Serializable
{
	String name;
	String breed;

	public Dog(String name,String breed)
	{
		this.name = name;
		this.breed = breed;
	}
}

class K
{
	public static void main(String args[])
	{
		Dog obj = new Dog("Tyson","Labrador");

		try
		{
			FileOutputStream f1 = new FileOutputStream("K.txt");

			ObjectOutputStream o1 = new ObjectOutputStream(f1);

			o1.writeObject(obj);

			FileInputStream f2 = new FileInputStream("K.txt");

			ObjectInputStream o2 = new ObjectInputStream(f2);

			// create Dog class's object like this also.
				Dog ObjDog = (Dog) o2.readObject();

				System.out.println("Dog name : " + ObjDog.name);
				System.out.println("Dog name : " + ObjDog.breed);

				o1.close();
				o2.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
