/* This program shows the demo of 'File class'.*/

import java.io.File;

public class FileDemo
{
	public static void main(String[] args)
	{
		File file1 = new File("A.dat");

		// Return true if directory or file exists else return false
		if(file1.exists())
		{
			// Return the name of the directory or file.
			System.out.println("\nFile Name : " + file1.getName() + " is exists..");
			
			if(file1.isDirectory())
			{
				System.out.println("true -- Directory");
			}
			else
			{
				System.out.println("false -- not Directory");
			}
			
			if(file1.isFile())
			{
				System.out.println("true -- it's a File");
			}
			else
			{
				System.out.println("false -- not a File");
			}
			
			if(file1.isHidden())
			{
				System.out.println("true -- Hidden");
			}
			else
			{
				System.out.println("false -- not Hidden");
			}

			// Return the path of the invoking object
			System.out.println("File path : " + file1.getPath());

			// Return the name of parent directory.
			System.out.println("Parent : " + file1.getParent());

			// Return the absolute path of the invoking object
			System.out.println("Absolute path : " + file1.getAbsolutePath());

			// Return the size of file in bytes.
			System.out.println("size of file : " + file1.length());

			// Return true if file object is readable else false.
			if(file1.canRead())
			{
				System.out.println("true -- Readable");
			}
			else
			{
				System.out.println("false -- Not Readable");
			}

			// Return true if file object is writable else false.
			if(file1.canWrite())
			{
				System.out.println("true -- Writable");
			}
			else
			{
				System.out.println("false -- Not Writable");
			}
		}
		else
		{
			System.out.println("File is not exists..");
		}
	}
}

/*
--> output :
darshan@darshan-Swift-SF314-43:~/Desktop/Advance Java/unit1$ javac FileDemo.java
darshan@darshan-Swift-SF314-43:~/Desktop/Advance Java/unit1$ java FileDemo

File Name : A.dat is exists..
false -- not Directory
true -- it's a File
false -- not Hidden
File path : A.dat
Parent : null
Absolute path : /home/darshan/Desktop/Advance Java/unit1/A.dat
size of file : 26
true -- Readable
true -- Writable
darshan@darshan-Swift-SF314-43:~/Desktop/Advance Java/unit1$ 
*/
