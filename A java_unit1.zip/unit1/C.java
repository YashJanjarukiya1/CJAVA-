/* File Writing using FileOutputStream.

Note : using FileOutputStream class empty file is 
automatically created. 	

-> THIS PROGRAM WRITE A CHARACTER 'A to Z' (BETWEEN 65 TO 91) INTO FILE
   IT GIVES THE DEMO OF FILEOUTPUTSTREAM CLASS. */

import java.io.*;

class C
{
	public static void main(String[] args)
	{
		try
		{
			FileOutputStream f1 = new FileOutputStream("A.dat");

			// writing a file
			for(int i=65; i<91; i++)
			{
				f1.write(i);
			}
			f1.close();

			System.out.println("File is created");
		}
		catch(IOException e)
		{
			System.out.println("error");
		}
	}
}