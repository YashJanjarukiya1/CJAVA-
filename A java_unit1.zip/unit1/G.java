/* 
--> Demo of BufferedInputStream class.
	Q.it Read data from file(with the use of FileInputStream)
	and display on the terminal.
______________________________________________________________*/ 
import java.io.*;

public class G
{
	public static void main(String[] args)
	{
		File f = new File("D.dat");

		try
		{
			BufferedInputStream bf = new BufferedInputStream(new FileInputStream(f));
			int a;

			while( ( a = bf.read() ) != -1 )
			{
				System.out.print((char)a);
			}
			bf.close();
		}
		catch(IOException e)
		{
			System.out.println("error " + e);
		}
	}
}
