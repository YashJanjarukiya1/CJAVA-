/*
--> Demo of BufferedOutputStream class.
	Q.Write static data to the file.
	(use the concept of BufferedOutputStream class).
________________________________________________________*/

import java.io.*;

public class H
{
	public static void main(String[] args)
	{
		try
		{
			BufferedOutputStream bf = new BufferedOutputStream(new FileOutputStream("E.dat"));

			// write static data in 'E.dat' file using getBytes() method
			bf.write("Hello world welcome to java programming".getBytes());
			bf.close();

			System.out.println("'E.dat' File is created");
		}
		catch(IOException e)
		{
			System.out.println("error");
		}
	}
}
