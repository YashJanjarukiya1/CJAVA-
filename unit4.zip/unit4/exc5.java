// Scenario where ArrayIndexOutOfBoundsException occurs
// it is also a type of RuntimeException.

public class exc5
{
    public static void main(String[] arg)
    { 
        try
        {   
            int []a = new int[5];
            a[10] = 20;

            for(int i=0;i<a.length;i++)
            {
                System.out.println(a[i]);
            }
        }
 
        catch(NumberFormatException e)
        {
            // Print the message if exception occurred
            System.out.println("ArrayIndexOutOfBoundException is occured in this case\n" + e);
        }
    }
}
