// A Class that represents use-defined(custom) exception
 
class MyException extends Exception 
{

}
 
// A Class that uses above MyException
public class custom2
{
    // Driver Program
    public static void main(String args[])
    {
        try 
        {
            // Throw an object of user defined exception
            throw new MyException();
        }
        catch (MyException ex)
        {
            System.out.println("Caught : " + ex);
        }
    }
}