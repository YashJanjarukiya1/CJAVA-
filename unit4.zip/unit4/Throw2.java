// throw exception using try and catch block.

class Throw2
{
	static void Valid()
	{
		int a = 30;
		try
		{
			if(a > 20)
			{
				throw new ArithmeticException();
			}
			else
			{
				System.out.println("Product price within Range");
			}
		}
		catch(ArithmeticException e)
		{
			System.out.println(e);
		}
		System.out.println("Rest of the code..");
	}
	public static void main(String[] args)
	{
		Valid();
		System.out.println("Radhe Radhe..");
	}
}