class Throw
{
	static void Valid(int age)
	{
		if(age<18)
		{
			throw new ArithmeticException("Not Valid..");
		}
		else
		{
			System.out.println("Welcome to vote");
		}
	}

	public static void main(String[] args)
	{
		Valid(3);
		System.out.println("Radhe Radhe..");
	}
}