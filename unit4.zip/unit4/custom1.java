
// a class representing custom exception (user-define exception) 
class CustomException extends Exception  
{  
    public String toString()
    {
        return "Hello from user-define(Custom) Exception";
    }
}  
        
// class that uses custom exception MyCustomException  
public class custom1
{  
    // main method  
    public static void main(String args[])  
    {  
        try  
        {  
            // throw an object of custom (user-defined) exception  
            throw new CustomException();  
        }  
        catch(CustomException ex)  
        {  
            System.out.println("Caught the exception");  
            System.out.println(ex.toString());  
        }  
        System.out.println("rest of the code...");    
    }  
}  