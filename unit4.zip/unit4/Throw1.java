class Throw1
{
	static void Valid()
	{
		int a = 10;
		if(a>20)
		{
			throw new ArithmeticException("Product price is greater");
		}
		else
		{
			System.out.println("Product price within Range");
		}
	}

	public static void main(String[] args)
	{
		Valid();
		System.out.println("Radhe Radhe..");
	}
}