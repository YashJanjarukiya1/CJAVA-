//  Java Throws Keyword
import java.io.IOException;
class Throws
{
	void m() throws IOException
	{
		throw new IOException("Device error");
	}

	void n() throws IOException
	{
		m();
	}

	void p()
	{
		try
		{
			n();
		}
		catch(Exception e)
		{
			System.out.println("Exception Handled");
		}
	}

	public static void main(String args[])
	{
		Throws t1 = new Throws();
		t1.p();
		System.out.println("Rest of the code..");
	}
}