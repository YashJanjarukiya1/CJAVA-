// Scenario where NumberFormatException occurs
// Note : NumberFormatException is a type of RuntimeException

public class exc3
{
    public static void main(String[] arg)
    { 
        // Try block to check if any exception occurs
        try
        {   
            String a = "abc";
            // Parsing user input to integer
            int i = Integer.parseInt(a);
            System.out.println("You entered : " + i);
        }
 
        // Catch block to handle NumberFormatException
        catch(NumberFormatException e)
        {
            // Print the message if exception occurred
            System.out.println("RuntimeException occurred\n" + e);
        }
    }
}
