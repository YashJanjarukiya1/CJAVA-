public class Throws2
{
    static void checkAge(int num) throws ArithmeticException
    {
        if(num > 18)
        {
            throw new ArithmeticException("Number is greater than 18");
        }
        else
        {
            System.out.println("Number is less than 18");
        }
    }

    public static void main(String[] args)
    {
        checkAge(20); // Set num to 15 (which is below 18...)
    }
}
