// isAlive()

public class Thread1_5 extends Thread
{
	public static int amount = 0;

	public static void main(String[] args)
	{

		Thread1_5 obj = new Thread1_5();
		obj.start();
		System.out.println(amount); // 0
		while(obj.isAlive())
		{
			System.out.println("Waiting");
		}

		// update amount and print its value
		System.out.println("Main : " + amount);
		amount++;

		System.out.println("Main : " + amount);	
	}

	public void run()
	{
		amount++;
	}
}

/*
--> output :
darshan@darshan-Swift-SF314-43:~/Desktop/CORE JAVA/unit-4/Thread$ javac Thread1_5.java
darshan@darshan-Swift-SF314-43:~/Desktop/CORE JAVA/unit-4/Thread$ java Thread1_5
0
Main : 1
Main : 2
darshan@darshan-Swift-SF314-43:~/Desktop/CORE JAVA/unit-4/Thread$ 
________________________________________________________________________________________*/