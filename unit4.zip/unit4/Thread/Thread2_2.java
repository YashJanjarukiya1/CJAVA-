class myClass implements Runnable 
{
	public void run()
	{
		for(int i=0;i<=10;i++)
		{
			try
			{
				Thread.sleep(100); // here, 100 milisecond time thread goes to sleep mode
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
			System.out.println(Thread.currentThread().getName() + " has value : " + i);
		}
	}
}

public class Thread2_2
{
	public static void main(String args[])
	{
		Thread t1 = new Thread(new myClass());
		Thread t2 = new Thread(new myClass());
		t1.start();
		try
		{
			t1.join();
		}
		catch(Exception m)
		{
			System.out.println(m);
		}
		t2.start();
	}
}