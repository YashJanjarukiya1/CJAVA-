//  Create a new thread by implementing Runnable Interface

class Thread2_1
{
	class Threading implements Runnable
	{
		public void run()
		{
			System.out.println("run() is call..");
		}
	}
	
	public static void main(String[] args)
	{
		Thread2_1 t2 = new Thread2_1();
		
		Thread t1 = new Thread(t2.new Threading());
		t1.start();
	}
}
