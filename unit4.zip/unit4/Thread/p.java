/*  Thread Priority */

public class p extends Thread   
{  
	// Whenever the start() method is called by a thread the run() method is invoked  
	public void run()  
	{  
		System.out.println("Inside the run() method");  
	}  
      
	// the main method  
	public static void main(String args[])  
	{  
		// Creating threads with the help of ThreadPriorityExample class  
		p t1 = new p();
		p t2 = new p();
		p t3 = new p();		
      
		// We did not mention the priority of the threads.  
		// Therefore, the priorities of the thread is 5 by default  
      
		// Displaying the priority of the threads using the getPriority() method  
		System.out.println("default Priority of t1 is : " + t1.getPriority());  
		System.out.println("default Priority of t2 is : " + t2.getPriority());  
		System.out.println("default Priority of t3 is : " + t3.getPriority());  
      
		// Setting priorities of above threads by passing integer arguments  
		t1.setPriority(6);  
		t2.setPriority(3);  
		t3.setPriority(9);  
      
		System.out.println("\nAfter set Priority of t1 is : " + t1.getPriority());  
		System.out.println("After set Priority of t2 is : " + t2.getPriority());  
		System.out.println("After set Priority of t3 is : " + t3.getPriority());  
      
		// Main thread  
		// Displaying name of the currently executing thread   
		System.out.println("\nCurrently Executing The Thread : " + Thread.currentThread().getName());  
		System.out.println("\ndefault Priority of the main thread is : " + Thread.currentThread().getPriority());  
		
		// Priority of the main thread is 10 now  
		Thread.currentThread().setPriority(10);  
		System.out.println("set the Priority of the main thread is : " + Thread.currentThread().getPriority());  
	}  
}  