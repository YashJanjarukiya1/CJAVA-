/*  Demonstration of thread priorities.

// setPriority() : this method is used to set the priority of the thread.
// getPriority() : this method is used to get the priority of the thread.
__________________________________________________________________________*/

public class p1 extends Thread
{
	public void run()
	{
		System.out.println("inside the run method");
	}
	
	public static void main(String[] args)
	{
		p1 p = new p1(); 
	
		System.out.println("default or current priority of thread is : " + p.getPriority()); // 5
		p.setPriority(10);
		System.out.println("after set the priority of thread is : " + p.getPriority()); // 10
	}
}