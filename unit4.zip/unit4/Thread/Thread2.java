//  Create a new thread by implementing Runnable Interface

class Thread2 implements Runnable
{
	public void run()
	{
		System.out.println("Thread is running");
	}

	public static void main(String args[])
	{
		Thread2 obj = new Thread2();
		Thread t1 = new Thread(obj);
		t1.start();
	}
}