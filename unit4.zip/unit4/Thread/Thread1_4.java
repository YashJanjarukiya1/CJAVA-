public class Thread1_4 extends Thread
{
	public static int amount = 0;

	public static void main(String args[])
	{
		Thread1_4 obj = new Thread1_4();
		obj.start();
		System.out.println(amount); // 0

		System.out.println(amount); // 1
		
		amount++; // 1 = 1 + 1
		System.out.println(amount); // 2
	}
	
	public void run()
	{
		amount++; // 0 = 0 + 1
	}
}