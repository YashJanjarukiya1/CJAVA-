//  Maximum Priority Thread

public class p3 extends Thread  
{    
        public void run()  
	{    
		System.out.println("Priority of thread is: "+Thread.currentThread().getPriority());    
        }    
        public static void main(String args[])  
        {    
		// creating one thread   
		p3 t1=new p3();    
		
		// print the maximum priority of this thread  
		t1.setPriority(Thread.MAX_PRIORITY);    
            
		// call the run() method  
		t1.start();    
        }    
}  