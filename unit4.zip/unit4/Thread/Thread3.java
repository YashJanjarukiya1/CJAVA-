public class Thread3 extends Thread
{
	public void run()
	{
		for(int i=1;i<=5;i++)
		{
			try
			{
				Thread.sleep(2500);
			}
			catch(Exception b)
			{
				System.out.println(b);
			}
			System.out.println(Thread.currentThread().getName() + " : " + i);
		}
	}

	public static void main(String args[])
	{
		Thread3 t1 = new Thread3();
		Thread3 t2 = new Thread3();
		Thread3 t3 = new Thread3();
		Thread3 t4 = new Thread3();

		t1.start();

		try 
		{
			t1.join(500);
		}
		catch(Exception c)
		{
			System.out.println(c);
		}

		t2.start();
		t3.start();
		t4.start();
	}
}