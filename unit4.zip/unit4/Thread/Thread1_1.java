// Thread Join

class Thread1_1 extends Thread
{
	public void run()
	{
		for(int i=1;i<=5;i++)
		{
			try
			{
				Thread.sleep(1000);
			}
			
			catch(Exception e)
			{
				System.out.println(e);
			}
			System.out.println(Thread.currentThread().getName() + " : " + i);
		}

	}

	public static void main(String[] args)
	{
		Thread1_1 t1 = new Thread1_1();
		Thread1_1 t2 = new Thread1_1();
		Thread1_1 t3 = new Thread1_1();
		Thread1_1 t4 = new Thread1_1();

		t1.start();

		try
		{
			t1.join();
		}
		catch(Exception m)
		{
			System.out.println(m);
		}

		t2.start();
		t3.start();
		t4.start();
	}
}