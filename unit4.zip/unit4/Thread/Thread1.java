//  Create a Thread By extending Thread class.

class Thread0 extends Thread
{
	public void run()
	{
		System.out.println("Thread is running");
	}
}

public class Thread1
{

	public static void main(String[] args)
	{
		Thread0 t1 = new Thread0();
		t1.start();
	}
}