// Join

public class Thread1_3 extends Thread
{
	public void run()
	{
		Thread t = new Thread();
		System.out.print(t.getName());

		// check if this thread is alive..
		System.out.println(" , " + t.isAlive());
	}

	public static void main(String[] args) throws Exception
	{
		Thread t = new Thread1_3();
		t.start();

		t.join(2000); // Thread sleeping time

		System.out.println("After waiting for 2000 miliseconds..");
		System.out.print(t.getName());

		System.out.println(" , " + t.isAlive());
	}
}