//  Normal Priority Thread

public class p5 extends Thread  
{    
        public void run()  
        {    
		System.out.println("Priority of thread is: "+Thread.currentThread().getPriority());    
        }    
        public static void main(String args[])  
        {    
		// creating one thread   
		p5 t1=new p5();    
		
		// print the normal priority of this thread  
		t1.setPriority(Thread.NORM_PRIORITY);    
		
		// This will call the run() method  
		t1.start();    
        }    
}  