// Thread priorities

class p2 extends Thread
{  
	public void run()
	{  
		System.out.println("running thread name is : "+Thread.currentThread().getName());  
		System.out.println("running " + getName() + " priority is : "+Thread.currentThread().getPriority());  
	}
	public static void main(String args[])
	{  
		p2 m1 = new p2();  
		p2 m2 = new p2();  
      
		m1.start();  
		m2.start();  
		
		m1.setPriority(Thread.MAX_PRIORITY);  
		m2.setPriority(Thread.MIN_PRIORITY);  
		
		//System.out.println("m1 running thread priority is:"+ m1.getPriority());  
		//System.out.println("m2 running thread priority is:"+ m2.getPriority());  
	}  
} 
/*
-> output :
darshan@darshan-Swift-SF314-43:~/Desktop/CORE JAVA/unit-4/Thread$ javac p2.java
darshan@darshan-Swift-SF314-43:~/Desktop/CORE JAVA/unit-4/Thread$ java p2
running thread name is : Thread-0
running thread name is : Thread-1
running Thread-0 priority is : 10
running Thread-1 priority is : 1
darshan@darshan-Swift-SF314-43:~/Desktop/CORE JAVA/unit-4/Thread$     
_____________________________________________________________________________________________*/    