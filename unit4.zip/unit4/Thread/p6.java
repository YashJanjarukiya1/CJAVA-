//  When priority is greater than 10, then Exception occur

public class p6 extends Thread  
{    
        public void run()  
        {    
		System.out.println("running...");    
        }    
        public static void main(String args[])  
        {    
		// creating one thread   
		p6 t1 = new p6();    
		p6 t2 = new p6();  
		
		// set the priority  
		t1.setPriority(10);  
		t2.setPriority(7);  
		
		// print exception because priority of t1 is greater than 10  
		System.out.println("Priority of thread t1 is: " + t1.getPriority());   
		System.out.println("Priority of thread t2 is: " + t2.getPriority());   
		
		// call the run() method  
		t1.start();  
		t2.start();
        }  
}  