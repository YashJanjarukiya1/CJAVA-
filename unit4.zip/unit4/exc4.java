// Exception is not occur in this case

public class exc4
{
    public static void main(String[] arg)
    { 
        try
        {   
            int []a = new int[5];
            a[0] = 1;
            a[1] = 2;
            a[2] = 3;
            a[3] = 4;
            a[4] = 5;

            for(int i=0;i<a.length;i++)
            {
                System.out.println(a[i]);
            }
        }
 
        catch(NumberFormatException e)
        {
            // Print the message if exception occurred
            System.out.println("Print the msg if exception is occured" + e);
        }
    }
}
